## 安装grpc
安装教程：[https://blog.csdn.net/QAZ600888/article/details/137181035?spm=1001.2014.3001.5501](https://blog.csdn.net/QAZ600888/article/details/137181035?spm=1001.2014.3001.5501)

## C++

#### 编译

1. 在cpp目录下新建build目录，执行cmake

   ```shell
   mkdir build
   cmake ..
   ```

2. 编译

   ```shell
   make
   ```

#### 运行

1. 运行grpc服务端，进入build/src/server/目录，执行./device_rpc_server

   ```shell
   cd build/src/server
   ./device_rpc_server
   ```

2. 运行grpc客户端，进入build/src/client/目录，执行./device_rpc_client

   ```shell
   cd build/src/client
   ./device_rpc_client
   ```

3. 服务端与客户端通信效果图

   ![](/resources/image/1.png)

## Python

#### 配置环境

1. 创建虚拟环境

   ```shell
   python3 -m venv venv
   ```

2. 进入虚拟环境

   ```python
   source venv/bin/activate
   ```

#### 运行

1. 运行服务端

   进入python/server目录，执行以下命令

   ```shell
   python3 device_rpc_server.py
   ```

2. 运行客户端

   进入python/client目录，执行以下命令

   ```shell
   python3 device_rpc_client.py
   ```

3. 服务端与客户端通信效果图

   ![](/resources/image/2.png)

## Python和C++互相调用

1. Python当服务端，C++当客户端

   ![](/resources/image/3.png)

2. C++当服务端，Python当客户端
   ![](/resources/image/4.png)